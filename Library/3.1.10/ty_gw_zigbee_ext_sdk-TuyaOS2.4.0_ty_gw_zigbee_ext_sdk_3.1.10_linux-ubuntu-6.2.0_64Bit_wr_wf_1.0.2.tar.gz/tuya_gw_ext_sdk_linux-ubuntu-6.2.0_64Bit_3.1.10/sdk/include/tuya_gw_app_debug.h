#ifndef __TUYA_GW_APP_DEBUG_H__
#define __TUYA_GW_APP_DEBUG_H__

#include "tuya_cloud_types.h"


#ifdef __cplusplus
    extern "C" {
#endif

/**
 * @brief 调试服务启动
 * 
 */
VOID tuya_gw_app_debug_start(CHAR_T * sto_dir);

#ifdef __cplusplus
}
#endif

#endif //!__TUYA_GW_APP_DEBUG_H__

