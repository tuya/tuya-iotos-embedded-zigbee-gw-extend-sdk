#ifndef __USER_KEY_H__
#define __USER_KEY_H__

#include "tuya_cloud_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief initiate key feature
 */
OPERATE_RET user_key_init(VOID);

#ifdef __cplusplus
}
#endif
#endif
