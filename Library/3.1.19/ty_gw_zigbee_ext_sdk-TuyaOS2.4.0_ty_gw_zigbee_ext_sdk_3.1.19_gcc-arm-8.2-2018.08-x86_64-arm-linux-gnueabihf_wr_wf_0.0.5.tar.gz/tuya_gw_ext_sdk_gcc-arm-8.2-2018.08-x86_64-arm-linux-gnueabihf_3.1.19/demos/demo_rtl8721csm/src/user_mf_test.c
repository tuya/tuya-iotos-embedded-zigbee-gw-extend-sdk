#include <string.h>

#include "mf_test.h"
#include "mem_pool.h"
#include "uni_log.h"
#include "uni_thread.h"
#include "wf_basic_intf.h"
#include "tuya_uart_legacy.h"
#include "tuya_os_adapter.h"
#include "tuya_hal_bt.h"
#include "tuya_hal_system.h"

// #include "tuya_zigbee_api.h"
#include "tuya_prod_test.h"
#include "tuya_testframe_handle.h"
#include "tuya_gw_prod_test_auth_info.h"

#include "user_mf_test.h"

#define MF_TEST_SSID                  "tuya_gw_prodtest"
#define MF_TEST_IP_ADDR               "192.168.175.1"
#define MF_TEST_IP_MASK               "255.255.255.0"

#define MF_TEST_PROTO                 "1.0.0"
#define MF_TEST_THREAD_NAME           "gw_mf_test"
#define MF_TEST_THREAD_PRIORITY       TRD_PRIO_0
#define MF_TEST_THREAD_STACKDEPTH     (8*1024)

#define MF_TEST_UART                  TY_UART0
#define MF_TEST_BUF_MAX               (6*1024 + 128)

STATIC BOOL_T g_uart_initd = FALSE;
STATIC BOOL_T g_pd_test_enter = FALSE;
STATIC BOOL_T g_zigbee_rftest_mode = FALSE;
STATIC INT_T g_zigbee_rftest_idx = -1;

STATIC INT_T __pd_test_uart_read_ready(VOID)
{
    if (ty_uart_read_data_size(MF_TEST_UART) > 0) {
        return 1;
    }

    return 0;
}

STATIC UINT_T __pd_test_uart_read(UCHAR_T *data, UINT_T len)
{
    return ty_uart_read_data(MF_TEST_UART, data, len);
}

STATIC UINT_T __pd_test_uart_write(UCHAR_T *data,  UINT_T len)
{
    ty_uart_send_data(MF_TEST_UART, data, len);

    return len;
}

STATIC VOID __pd_test_msleep(unsigned long timems)
{
    tuya_hal_system_sleep(timems);
}

STATIC INT_T __pd_test_create_thread_and_run(thread_process thr_process, VOID **handle)
{
    THRD_PARAM_S thrd_param = { 
        .stackDepth = MF_TEST_THREAD_STACKDEPTH,
        .thrdname   = MF_TEST_THREAD_NAME,
        .priority   = MF_TEST_THREAD_PRIORITY,
    };

    if (thr_process == NULL) {
        PR_ERR("thr_process is null");
        return OPRT_INVALID_PARM;
    }

    return CreateAndStart(handle, NULL, NULL, thr_process, NULL, &thrd_param);
}

STATIC INT_T __pd_test_cancel_thread(VOID *handle)
{
    return DeleteThrdHandle(handle);
}

STATIC INT_T __pd_test_enter(CHAR_T *out_buf)
{
    if (out_buf == NULL)
        return -1;

    // TODO
    sprintf(out_buf,"{\"comProtocol\":\"%s\",\"deviceType\":\"rtl8720cm\",\"writeMac\":\"true\",\"writePskKey\":true}", MF_TEST_PROTO);

    g_pd_test_enter = TRUE;

    return 0;
}

STATIC INT_T __pd_test_exit(CHAR_T *out_buf)
{
    if (out_buf == NULL)
        return -1;

    // TODO
    sprintf(out_buf,"{\"comProtocol\":\"%s\",\"deviceType\":\"rtl8720cm\",\"writeMac\":\"true\",\"writePskKey\":true}", MF_TEST_PROTO);

    g_pd_test_enter = FALSE;

    return 0;
}

STATIC INT_T __pd_test_r_master_firmware_info(CHAR_T *out_buf)
{
    if (out_buf == NULL)
        return -1;

    sprintf(out_buf,"{\"ret\":true,\"firmName\":\"%s\",\"firmVer\":\"%s\"}", APP_BIN_NAME, USER_SW_VER);
    
    return 0;
}

STATIC INT_T __pd_test_ble_rf_test(CHAR_T *ssid, INT_T *rssi)
{
    ty_bt_scan_info_t ble_scan;
    OPERATE_RET op_ret = OPRT_OK;

    if ((NULL == ssid) || (NULL == rssi)) {
        PR_ERR("scan BLE ssid input param error");
        return -1;
    }

    memset(&ble_scan, 0x00, SIZEOF(ble_scan));
    strncpy(ble_scan.name, ssid, strlen(ssid));

    PR_NOTICE("scan ble name = %s", ble_scan.name);
    ble_scan.scan_type = TY_BT_SCAN_BY_NAME;
    ble_scan.timeout_s = 5;
    op_ret = tuya_hal_bt_assign_scan(&ble_scan);
    if (OPRT_OK != op_ret) {
        PR_ERR("###### bt scan err: %d #######", op_ret);
        return -1;
    }
    *rssi = ble_scan.rssi;

    PR_NOTICE("BT Name: %s RSSI: %d", ble_scan.name, *rssi);

    return 0;
}

STATIC INT_T __pd_test_wifi_rf_test(CHAR_T *ssid, INT_T *rssi)
{
    OPERATE_RET op_ret = OPRT_OK;
    AP_IF_S *ap = NULL;

    if ((NULL == ssid) || (NULL == rssi)) {
        PR_ERR("scan WIFI ssid input param error");
        return -1;
    }

    op_ret = wf_assign_ap_scan(ssid, &ap);
    if(OPRT_OK != op_ret) {
        PR_ERR("wf_assign_ap_scan failed.");
        return -1;
    }else {
        *rssi = ap->rssi;
        wf_release_ap(ap);
    }

    return 0;
}

#if 0
STATIC VOID __zigbee_rftest_result_cb(USHORT_T npacket)
{
    g_zigbee_rftest_mode = FALSE;

    if (g_zigbee_rftest_mode) {
        tuya_testframe_rep_zigbeeRf_event(g_zigbee_rftest_idx, npacket);
    }
}

STATIC INT_T __pd_test_zigbee_rf_test(INT_T index, INT_T channel, INT_T num)
{
    UCHAR_T data[] = { 0x55, 0xaa, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39 };

    if (g_zigbee_rftest_mode) {
        PR_WARN("zigbee rftest is running");
        return -1;
    }

    g_zigbee_rftest_idx = index;
    tuya_zigbee_rftest(__zigbee_rftest_result_cb, channel, -20, CNTSOF(data), data, num);                          
    g_zigbee_rftest_mode = TRUE;

    return 0;
}
#endif

STATIC VOID __pd_test_reboot(VOID)
{
    tuya_hal_system_reset();
}

STATIC OPERATE_RET __pd_test_ap_config(VOID)
{
    OPERATE_RET op_ret = OPRT_OK;
    WF_AP_CFG_IF_S *cfg = NULL;
    NW_MAC_S mac;

    cfg = Malloc(SIZEOF(WF_AP_CFG_IF_S));
    if (NULL == cfg) {
        return OPRT_MALLOC_FAILED;
    }
    memset(cfg, 0, SIZEOF(WF_AP_CFG_IF_S));

    memcpy(cfg->ssid, MF_TEST_SSID, strlen(MF_TEST_SSID));
    cfg->s_len = strlen(MF_TEST_SSID);
    cfg->max_conn = 3;
    cfg->ms_interval = 100;
    strncpy(cfg->ip.ip, MF_TEST_IP_ADDR, SIZEOF(cfg->ip.ip));
    strncpy(cfg->ip.gw, MF_TEST_IP_ADDR, SIZEOF(cfg->ip.gw));
    strncpy(cfg->ip.mask, MF_TEST_IP_MASK, SIZEOF(cfg->ip.mask));
    cfg->md = WAAM_OPEN;

    memset(&mac, 0, SIZEOF(NW_MAC_S));

    op_ret = wf_get_mac(WF_STATION, &mac);
    if (op_ret != OPRT_OK) {
        Free(cfg);
        return op_ret;
    }

    sprintf((CHAR_T *)cfg->ssid, "%s_%02X%02X", (CHAR_T *)cfg->ssid, mac.mac[4], mac.mac[5]);
    PR_NOTICE("##### MF TEST AP SSID : %s #####", cfg->ssid);
    cfg->chan = 5;
    cfg->s_len += 5;

    op_ret = wf_ap_start(cfg);
    Free(cfg);
    if(op_ret != OPRT_OK) {
        return op_ret;
    }

    return OPRT_OK;
}

STATIC OPERATE_RET __mf_test_testframe_handle_init(TUYA_PRODTEST_MODE mode)
{
    OPERATE_RET op_ret = OPRT_OK;
    TNFH_HANDLER __sys_cbs = {
        .msleep                = __pd_test_msleep,
        .create_thread_and_run = __pd_test_create_thread_and_run,
        .cancel_thread         = __pd_test_cancel_thread,
    };

    op_ret = tuya_testframe_register_nolinux_func(&__sys_cbs);
    if (op_ret < 0) {
        PR_ERR("tuya_testframe_register_nolinux_func err: %d", op_ret);
        return op_ret;
    }

    TYTEST_FRAME_CBS_S __prodframe_cbs = {
        .enter_prodtest_frame_cb     = __pd_test_enter,
        .exit_prodtest_frame_cb      = __pd_test_exit,
        .master_firm_frame_cb        = __pd_test_r_master_firmware_info,
        .w_cfg_frame_cb              = tuya_gw_pd_test_w_auth_info,
        .r_cfg_frame_cb              = tuya_gw_pd_test_r_auth_info,
        .w_master_mac_frame_cb       = tuya_gw_pd_test_w_master_mac,
        .r_master_mac_frame_cb       = tuya_gw_pd_test_r_master_mac,
        .w_slave_mac_frame_cb        = tuya_gw_pd_test_w_slave_mac,
        .w_country_frame_cb          = tuya_gw_pd_test_w_country_code,
        .r_country_frame_cb          = tuya_gw_pd_test_r_country_code,
        // .zigbee_rf_frame_cb          = __pd_test_zigbee_rf_test,
        .ble_rf_frame_cb             = __pd_test_ble_rf_test,
        .wifi_rf_frame_cb            = __pd_test_wifi_rf_test,
        // .upgrade_cfg_frame_cb        = tuya_gw_pd_test_upgrade_cfg,
        // .upgrade_start_frame_cb      = tuya_gw_pd_test_upgrade_start,
        // .upgrade_rev_packet_frame_cb = tuya_gw_pd_test_upgrade_rev,
        // .upgrade_end_frame_cb        = tuya_gw_pd_test_upgrade_end,
        .reboot_frame_cb             = __pd_test_reboot,
    };

    op_ret = tuya_testframe_handle_init(mode, &__prodframe_cbs);
    if (op_ret < 0) {
        PR_ERR("tuya_testframe_handle_init err: %d", op_ret);
        return op_ret;
    }

    return OPRT_OK;
}

STATIC OPERATE_RET __mf_test_uart_init(VOID)
{
    OPERATE_RET op_ret = OPRT_OK;
    TPUART_HANDLER __tpuart_cbs = {
        .read_ready = __pd_test_uart_read_ready,
        .uread      = __pd_test_uart_read,
        .uwrite     = __pd_test_uart_write,
    };

    if (g_uart_initd) {
        PR_WARN("mf test uart had been initd");
        return OPRT_OK;
    }

    ty_uart_flowctrl_init(MF_TEST_UART, TYU_RATE_9600, TYWL_8B, TYP_NONE, TYS_STOPBIT1, MF_TEST_BUF_MAX, TRUE, FALSE);

    op_ret = tuya_testframe_register_uart_func(&__tpuart_cbs);
    if (op_ret != OPRT_OK) {
        PR_WARN("tuya_testframe_register_uart_func err: %d", op_ret);
    }

    // TUYA_CALL_ERR_RETURN(__ty_gw_pd_testframe_handle_init(TPM_SERIAL));

    // cur_prod_mode = TPM_SERIAL;

    g_uart_initd = TRUE;

    return OPRT_OK;
}

STATIC OPERATE_RET __mf_test_tcp_init(VOID)
{
    OPERATE_RET op_ret = OPRT_OK;

    op_ret = wf_wk_mode_set(WWM_SOFTAP);
    if (op_ret != OPRT_OK) {
        PR_ERR("wf_wk_mode_set err: %d", op_ret);
        return op_ret;
    }

    op_ret = __pd_test_ap_config();
    if (op_ret != OPRT_OK) {
        PR_ERR("__pd_test_ap_config err: %d", op_ret);
        return op_ret;
    } 

    return OPRT_OK;
}

STATIC OPERATE_RET __mf_test_uart_deinit(VOID)
{
    if (g_uart_initd) {
        ty_uart_free(MF_TEST_UART);
    }
    
    g_uart_initd = FALSE;

    tuya_testframe_handle_deinit();

    return OPRT_OK;
}

OPERATE_RET user_mf_test_uart_detect(VOID)
{
    OPERATE_RET op_ret = OPRT_OK;
    INT_T time_cnt = 0;

    if (TRUE == wd_mf_test_close_if_read()) {
        PR_NOTICE("-> have actived over 15 min, stop mf test");
        return OPRT_TIMEOUT;
    }

    op_ret = __mf_test_uart_init();
    if (op_ret != OPRT_OK) {
        PR_ERR("__mf_test_uart_init err: %d", op_ret);
        return op_ret;
    }

    op_ret = __mf_test_testframe_handle_init(TPM_SERIAL);
    if (op_ret != OPRT_OK) {
        PR_ERR("__mf_test_testframe_handle_init err: %d", op_ret);
        return op_ret;
    }

    while (1) {
        if (g_pd_test_enter)
            break;

        tuya_hal_system_sleep(50);

        if (++time_cnt >= 10) {
            PR_WARN("##### MF TEST UART TIMEOUT #####");
            __mf_test_uart_deinit();
            return OPRT_TIMEOUT;
        }
    }

    PR_NOTICE("##### gateway mf test is ready #####");

    return OPRT_OK;
}

OPERATE_RET user_mf_test_init(TUYA_PRODTEST_MODE mode)
{
    OPERATE_RET op_ret = OPRT_OK;

    if (mode == TPM_SERIAL) {
        op_ret = __mf_test_uart_init();
        if (op_ret != OPRT_OK) {
            PR_ERR("__mf_test_uart_init err: %d", op_ret);
            return op_ret;
        }
        PR_NOTICE("__mf_test_uart_init success");
    } else if (mode == TPM_TCP) {
        op_ret = __mf_test_tcp_init();
        if (op_ret != OPRT_OK) {
            PR_ERR("__mf_test_tcp_init err: %d", op_ret);
            return op_ret;
        }
        PR_NOTICE("__mf_test_tcp_init success");
    } else {
        PR_ERR("No support prod_test mode");
        return OPRT_INVALID_PARM;
    }

    op_ret = __mf_test_testframe_handle_init(mode);
    if (op_ret != OPRT_OK) {
        PR_ERR("__mf_test_testframe_handle_init err: %d", op_ret);
        return op_ret;
    }

    PR_NOTICE("##### gateway mf test is ready #####");

    return OPRT_OK;
}
