#ifndef __USER_MF_TEST_H__
#define __USER_MF_TEST_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"
#include "tuya_cloud_com_defs.h"

#include "tuya_prod_test.h"

/**
 * @brief user_mf_test_uart_detect 检测是否进入产测模式，阻塞 500ms
 * 
 * @return OPERATE_RET
 */
OPERATE_RET user_mf_test_uart_detect(VOID);

OPERATE_RET user_mf_test_init(TUYA_PRODTEST_MODE mode);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __USER_MF_TEST_H__