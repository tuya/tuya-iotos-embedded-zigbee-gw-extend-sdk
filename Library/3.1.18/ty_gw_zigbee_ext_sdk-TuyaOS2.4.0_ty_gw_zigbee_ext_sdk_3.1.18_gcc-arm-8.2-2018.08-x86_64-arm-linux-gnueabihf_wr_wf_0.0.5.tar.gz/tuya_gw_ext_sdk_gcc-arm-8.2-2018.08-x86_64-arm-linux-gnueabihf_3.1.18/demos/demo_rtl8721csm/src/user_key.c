#include "tuya_gpio.h"
#include "tuya_gw_key.h"
#include "uni_log.h"

#include "user_key.h"

#define GW_RESET_KEY     TY_GPIOB_23

STATIC KEY_USER_CB_INFO_T s_rst_cb_info[] =
{
    { NORMAL_KEY     , DEFINE_CUSTOM },
    { SEQ_KEY        , DEFINE_CUSTOM },
    { LONG_KEY       , DEFINE_CUSTOM },
};

STATIC KEY_USER_CB_INFO_TABLE_T s_cb_table[] =
{
    {(KEY_USER_CB_INFO_T *)&s_rst_cb_info, CNTSOF(s_rst_cb_info)},
};

STATIC VOID __rst_key_value_cb(IN INT_T port, OUT BOOL_T *level)
{
    *level = tuya_gpio_read(port);
}

STATIC VOID __rst_key_cb(IN INT_T port, IN KEY_PUSH_TYPE_E type, IN INT_T cnt)
{
    PR_NOTICE("KEY trigger, type: %d, cnt: %d", type, cnt);

    if (type == LONG_KEY) {
        PR_DEBUG("gw local unactive");
        tuya_iot_wf_gw_unactive();
    }
}

OPERATE_RET user_key_init(VOID)
{
    OPERATE_RET op_ret = OPRT_OK;
    KEY_USER_DEF_T rst_key = {
        .port                = GW_RESET_KEY,
        .low_level_detect    = TRUE,
        .lp_tp               = LP_ONCE_TRIG,
        .long_key_time       = 5000,
        .seq_key_detect_time = 400,
        .get_key_value_cb    = __rst_key_value_cb,
    };

    // Initiate GPIO and set its direction to input
    op_ret = tuya_gpio_inout_set(GW_RESET_KEY, TRUE);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_gpio_inout_set err: %d", op_ret);
        return;
    }
    
    op_ret = tuya_gw_key_init(1024*3, 20);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_gw_key_init err: %d", op_ret);
        return;
    }

    op_ret = tuya_gw_reg_proc_key(&rst_key, __rst_key_cb, &s_cb_table);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_gw_reg_proc_key err: %d", op_ret);
        return;
    }
}
