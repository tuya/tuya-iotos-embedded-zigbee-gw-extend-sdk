#include "tuya_cloud_types.h"

/**
 * @brief 产测初始化前置准备工作
 * @note 如果不需要，则实现空函数。
 *      
 * @return VOID_T 
 */
VOID pre_mf_init(VOID)
{
	return;
}

/**
 * @brief pre_gpio_test gpio测试前置接口，用于对gpio测试做准备工作，
 * 例如对gpio进行重新初始化，或者是关闭gpio test，关闭gpio test的时候，
 * gpio test会返回Ture
 * @note 应用必须对其进行实现，如果不需要，则实现空函数
 * 
 * @return VOID_T 
 */
VOID_T mf_user_pre_gpio_test_cb(VOID_T)
{
    return;
}

/**
 * @brief mf_user_enter_callback 是配置进入产测回调接口
 * @note 应用必须对其进行实现，如果不需要，则实现空函数
 * 
 * @return VOID_T 
 */
VOID_T mf_user_enter_callback(VOID_T)
{
    return;
}

/**
 * @brief mf_user_callback 是配置写入回调接口
 * @note 应用必须对其进行实现，如果不需要，则实现空函数
 * 
 * @return VOID_T 
 */
VOID_T mf_user_callback(VOID_T)
{
    return;
}

/**
 * @brief mf_user_product_test_cb 是成品产测回调接口
 * @note 应用必须对其进行实现，如果不需要，则实现空函数
 * 
 * @return VOID_T 
 */
OPERATE_RET mf_user_product_test_cb(USHORT_T cmd,UCHAR_T *data, UINT_T len, OUT UCHAR_T **ret_data,OUT USHORT_T *ret_len)
{
    return OPRT_OK;
}

/**
 * @brief 硬件复位Zigbee模组
 * @note 应用必须对其进行实现，如果不需要，则实现空函数
 */
VOID hal_gw_hard_reset_zigbee(VOID)
{
    return;
}

VOID backtrace_stack_check(VOID *pspstack, VOID *mspstack, UINT_T lr_addr, UINT_T fault_id)
{
    return;
}

VOID backtrace_port_hal_init(VOID)
{
    return;
}
