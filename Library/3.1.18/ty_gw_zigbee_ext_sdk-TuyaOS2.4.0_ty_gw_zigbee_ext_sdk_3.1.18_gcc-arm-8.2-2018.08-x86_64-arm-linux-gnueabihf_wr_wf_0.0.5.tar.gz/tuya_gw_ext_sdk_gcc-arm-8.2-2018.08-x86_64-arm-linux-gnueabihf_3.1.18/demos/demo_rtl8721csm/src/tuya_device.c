/**
 * @file tuya_device.c
 * @brief user main file
 * 
 * @copyright Copyright (c) tuya.inc 2021
 */
#include <string.h>

#include "uni_log.h"
#include "mem_pool.h"
#include "ty_cJSON.h"
#include "tuya_gpio.h"
#include "tuya_iot_com_api.h"
#include "tuya_gw_com_defs.h"
#include "tuya_gw_subdev_api.h"

#include "tuya_gw_infra_api.h"

#include "user_key.h"
#include "user_mcu.h"
#include "user_zigbee_local.h"

#define UUID         "tuya461dbc63aeeb991f"
#define AUTHKEY      "c8X4PR4wx1gMFaQlaZu5dfgVvVRwB8Ug"
#define PRODUCT_KEY  "fljmamufiym5fktz"

#define ZIGBEE_BOOT_GPIO TY_GPIOB_4

#define DEMO_TEST 1

STATIC INT_T __get_uuid_authkey_cb(CHAR_T *uuid, INT_T uuid_size, CHAR_T *authkey, INT_T authkey_size);
STATIC INT_T __get_product_key_cb(CHAR_T *pk, INT_T pk_size);
STATIC INT_T __gw_active_status_changed_cb(ty_gw_status_t status);
STATIC INT_T __gw_online_status_changed_cb(BOOL_T online);
STATIC VOID __gw_reboot_cb(VOID);
STATIC VOID __gw_reset_cb(VOID);

/**
 * @brief 应用初始化前置准备工作
 * 
 * @return VOID_T 
 * 
 * @note 在此函数中，应用可以执行一些配置设置、事件关注等和具体功能操作无关的工作，应用必须对其进行实现，如果不需要，则实现空函数。
 */
VOID_T pre_app_init(VOID_T)
{
    printf("\r\npre_app_init, free mem: %d KB\n", tuya_os_adapt_system_getheapsize() >> 10);
}

/**
 * @brief 应用初始化接口
 * 
 * @return VOID_T 
 * 
 * @note 在此函数，应用进行自身的初始化工作，应用必须对其进行实现，如果不需要，则实现空函数。
 */
VOID app_init(VOID_T)
{
    OPERATE_RET op_ret = OPRT_OK;

    // tuya_gw_pd_test_set_mac();

#if 0
    if (OPRT_OK == user_mf_test_uart_detect()) {
        // 产测上位机触发进入产测
        app_cfg_set(GWCM_OLD, NULL);
    } else {
        // 产测路由器扫描触发进入产测
        app_cfg_set(GWCM_OLD_PROD, __prod_test_cb);
    }
#endif

    return;
}

/**
 * @brief 设备初始化前置准备工作
 * 
 * @return VOID_Ts 
 * 
 * @note 应用必须对其进行实现，如果不需要，则实现空函数
 */
VOID pre_device_init(VOID_T)
{
    SET_PR_DEBUG_LEVEL(TY_LOG_LEVEL_DEBUG);
    PR_NOTICE("SDK INFO: %s", tuya_iot_get_sdk_info());

    // Zigbee 模组硬件复位引脚
    tuya_gpio_inout_set(ZIGBEE_BOOT_GPIO, FALSE);
    tuya_gpio_write(ZIGBEE_BOOT_GPIO, TRUE);
}

/**
 * @brief 设备初始化接口
 * 
 * @return OPERATE_RET 
 * 
 * @note 应用必须对其进行实现，如果不需要，则实现空函数
 */
OPERATE_RET device_init(VOID_T)
{
    OPERATE_RET op_ret = OPRT_OK;

    ty_gw_attr_s gw_attr = {
        .tty_device = "1",
        .ver        = "1.0.1",
        .dev_max    = 128,
        .wifi_mode  = TY_CONN_MODE_AP_ONLY,
        .log_level  = TY_LOG_DEBUG,
    };

    ty_gw_infra_cbs_s gw_cbs = {
        .get_product_key_cb          = __get_product_key_cb,
        .get_uuid_authkey_cb         = __get_uuid_authkey_cb,
        .gw_reboot_cb                = __gw_reboot_cb,
        .gw_reset_cb                 = __gw_reset_cb,
        .gw_active_status_changed_cb = __gw_active_status_changed_cb,
        .gw_online_status_changed_cb = __gw_online_status_changed_cb,
    };

#if DEMO_TEST
    op_ret = user_mcu_set_ota_channel("1.0.0");
    if (op_ret != OPRT_OK) {
        PR_ERR("user_mcu_set_ota_channel err: %d", op_ret);
        return op_ret;
    }
#endif

    op_ret = tuya_user_iot_init(&gw_attr, &gw_cbs);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_user_iot_init err: %d", op_ret);
        return op_ret;
    }

#if DEMO_TEST
    tuya_gpio_inout_set(TY_GPIOA_25, FALSE);
    tuya_gpio_write(TY_GPIOA_25, TRUE);
    tuya_gpio_inout_set(TY_GPIOB_22, FALSE);
    tuya_gpio_write(TY_GPIOB_22, TRUE);

    op_ret = user_zigbee_local_init();
    if (op_ret != OPRT_OK) {
        PR_ERR("user_zigbee_local_init err: %d", op_ret);
        return op_ret;
    }

    op_ret = user_key_init();
    if (op_ret != OPRT_OK) {
        PR_ERR("user_key_init err: %d", op_ret);
        return op_ret;
    }
#endif

    PR_NOTICE("device_init success...");

    return op_ret;
}

STATIC VOID_T __prod_test_cb(BOOL_T flag, SCHAR_T rssi)
{
    PR_NOTICE("net prod_test, flag: %d , rssi: %d", flag, (SCHAR_T)rssi);

    // user_mf_test_init(TPM_TCP);

    return;
}

STATIC INT_T __get_uuid_authkey_cb(CHAR_T *uuid, INT_T uuid_size, CHAR_T *authkey, INT_T authkey_size)
{
    strncpy(uuid, UUID, uuid_size);
    strncpy(authkey, AUTHKEY, authkey_size);

    return OPRT_OK;
}

STATIC INT_T __get_product_key_cb(CHAR_T *pk, INT_T pk_size)
{
    strncpy(pk, PRODUCT_KEY, pk_size);

    return OPRT_OK;
}

STATIC VOID __gw_reboot_cb(VOID)
{
    PR_DEBUG("reboot callback");
}

STATIC VOID __gw_reset_cb(VOID)
{
    PR_DEBUG("reset callback");
}

STATIC INT_T __gw_active_status_changed_cb(ty_gw_status_t status)
{
    PR_DEBUG("gw active status changed cb, status = %d", status);

    return OPRT_OK;
}

STATIC INT_T __gw_online_status_changed_cb(BOOL_T online)
{
    PR_DEBUG("gw online status changed cb, online = %d", online);

    return OPRT_OK;
}

