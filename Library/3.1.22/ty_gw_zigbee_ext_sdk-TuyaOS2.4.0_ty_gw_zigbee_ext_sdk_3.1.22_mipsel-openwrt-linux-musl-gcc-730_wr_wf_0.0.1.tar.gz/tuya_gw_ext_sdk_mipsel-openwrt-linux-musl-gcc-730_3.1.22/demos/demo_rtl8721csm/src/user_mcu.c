#include <stdlib.h>
#include <string.h>

#include "uni_log.h"
#include "tuya_iot_com_api.h"
#include "tuya_gw_infra_api.h"

#include "user_mcu.h"

STATIC OPERATE_RET __gw_mcu_upgrade_data_cb(IN CONST FW_UG_S *fw, IN CONST UINT_T total_len, IN CONST UINT_T offset,
                                            IN CONST BYTE_T *data, IN CONST UINT_T len, OUT UINT_T *remain_len, IN PVOID_T pri_data)
{
    return OPRT_OK;
}

STATIC VOID __gw_mcu_upgrade_notify_cb(IN CONST FW_UG_S *fw, IN CONST INT_T download_result, IN PVOID_T pri_data)
{
    if (download_result == 0) {
        PR_DEBUG("fw download success");
    }
}

STATIC INT_T __gw_mcu_upgrade_cb(CONST FW_UG_S *fw)
{
    PR_DEBUG("recv mcu upgrade notification");

    tuya_iot_upgrade_gw(fw, __gw_mcu_upgrade_data_cb, __gw_mcu_upgrade_notify_cb, NULL);

    return OPRT_OK;
}

OPERATE_RET user_mcu_set_ota_channel(CONST CHAR_T *cur_ver)
{
    OPERATE_RET op_ret = OPRT_OK;
    ty_gw_ota_channel_s gw_ota_channels;

    if (cur_ver == NULL) {
        return OPRT_INVALID_PARM;
    }

    memset(&gw_ota_channels, 0, SIZEOF(gw_ota_channels));
    gw_ota_channels.attr.tp = GP_DEV_MCU;
    gw_ota_channels.cb      = __gw_mcu_upgrade_cb;
    strncpy(gw_ota_channels.attr.ver, cur_ver, SIZEOF(gw_ota_channels.attr.ver));

    op_ret = tuya_user_iot_set_ota_channel(&gw_ota_channels, 1);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_user_iot_set_ota_channel err: %d", op_ret);
        return op_ret;
    }

    return OPRT_OK;
}
