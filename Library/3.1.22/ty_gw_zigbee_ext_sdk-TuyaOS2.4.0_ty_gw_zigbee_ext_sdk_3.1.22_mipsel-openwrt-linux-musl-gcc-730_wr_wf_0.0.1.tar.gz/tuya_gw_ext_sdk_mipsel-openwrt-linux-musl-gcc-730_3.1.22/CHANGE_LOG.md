Release notes:  

3.1.20
    - Add scene_linkage_load_all_rule_info_from_disk API
    - Fix some known bugs

3.1.18
    - Update to TYGWZ-01 v1.20.0
    - Add tuya_user_iot_misc_dev_bind_ext API
    - Add tuya_user_iot_misc_dev_ver_update_ext API
    - Add tuya_user_iot_misc_dev_upgd_progress_report API
    - Add misc_dev_upgrade_v2_cb callback

3.1.2
    - Add tuya_user_iot_set_log_level API
    - Add tuya_user_iot_reg_dev_mgr API
    - Add tuya_user_iot_get_gw_stat API
    - Fix re-open udp socket when IP address changed
    - Fix fault replacement is disabled by default

3.1.0  
    - Update to TYGWZ-01 v1.12.0  
    - Add third-party ZigBee device read version response callback  
    - Add sub-device online stat notification callback  
    - Fix gateway will offline when network is unstable  
    - Fix db data lost bug  
    - Optimize sub-device online stat management  

3.0.2  
    - Add ZigBee detection feature  
    - Add country code setting  
    - Add max device number setting, and default is 1024  
    - Add gateway fault replacement feature  
    - Add ZigBee NCP firmware upgrade API  
    - Fix log level doesn't work  
    - Fix 3rd-party ZigBee will be removed after reboot  
    - Fix device heartbeat configuration will be modified unexpectedly  
    - Fix reset callback will be called when bind device  
 
3.0.1  
    - Update to TYGWZ-01 v1.10.1  
    - Update custom ZigBee device management API  

1.0.6  
    - Fix production mode doesn't work  
    - Add rtl8196e and rtl8197f hardware platform  

1.0.5  
    - Fix segmentfault caused by wrong uz_cfg    
    - Add zigbee rf test tool   

1.0.4  
    - Fix storage path doesn't work  
    - Add gateway active and operation mode api  

1.0.3  
    - Fix hadn't call z3_dev_leave_cb function when device left  

1.0.2  
    - Fix third-party Zigbee device will be removed  
    - Fix segmentfault raised by door lock device  

1.0.1  
    - Add home security feature  
    - Add engineering mode  
    - Fix cannot switch between EZ and AP mode  

1.0.0   
    - Initial version  

