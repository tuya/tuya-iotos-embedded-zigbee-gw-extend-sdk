#ifndef __USER_MCU_H__
#define __USER_MCU_H__

#include "tuya_cloud_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief register mcu ota channel
 *
 * @param[in] cur_ver mcu firmware version
 *
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
OPERATE_RET user_mcu_set_ota_channel(CONST CHAR_T *cur_ver);

#ifdef __cplusplus
}
#endif
#endif
