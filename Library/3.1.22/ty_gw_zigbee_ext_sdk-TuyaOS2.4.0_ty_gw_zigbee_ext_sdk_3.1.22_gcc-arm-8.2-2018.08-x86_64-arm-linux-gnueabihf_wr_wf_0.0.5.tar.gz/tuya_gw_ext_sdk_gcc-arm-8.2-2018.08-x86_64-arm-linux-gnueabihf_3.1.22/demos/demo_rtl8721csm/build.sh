#!/bin/sh

set -e

APP_NAME=$1
APP_VERSION=$2
TARGET_PLATFORM=$3
USER_CMD=$4

ROOT_DIR=$(pwd)/../..
OUTPUT_DIR=${ROOT_DIR}/output/${APP_NAME}_${APP_VERSION}

[ -z $APP_NAME ] && echo "no app name!" && exit 99
[ -z $APP_VERSION ] && echo "no version!" && exit 99
[ -z $TARGET_PLATFORM ] && echo "no platform!" && exit 99

echo "**************************************"
echo "APP_NAME:         $APP_NAME"
echo "APP_VERSION:      $APP_VERSION"
echo "TARGET_PLATFORM:  $TARGET_PLATFORM"
echo "USER_CMD:         $USER_CMD"
echo "COMPILE_PREX:     $COMPILE_PREX"
echo "OUTPUT_DIR:       $OUTPUT_DIR"
echo "**************************************"

PLATFORM_BUILD_PATH_FILE=${ROOT_DIR}/platforms/$TARGET_PLATFORM/toolchain/build_path
if [ -e $PLATFORM_BUILD_PATH_FILE ]; then
    . $PLATFORM_BUILD_PATH_FILE
else
    echo "$PLATFORM_BUILD_PATH_FILE not found in platform[$TARGET_PLATFORM]!"
	exit 1
fi

if [ "$USER_CMD" = "clean" ];then
	cd ${ROOT_DIR}/platforms/$TARGET_PLATFORM/toolchain/$TUYA_APPS_BUILD_PATH/
	sh $TUYA_APPS_BUILD_CMD clean
	exit 1
fi

echo "*******************build application start*******************"
if [ -f ${ROOT_DIR}/platforms/$TARGET_PLATFORM/toolchain/$TUYA_APPS_BUILD_PATH/$TUYA_APPS_BUILD_CMD ]; then
    cd ${ROOT_DIR}/platforms/$TARGET_PLATFORM/toolchain/$TUYA_APPS_BUILD_PATH
	sh $TUYA_APPS_BUILD_CMD $APP_NAME $APP_VERSION $OUTPUT_DIR
else
	echo "No found build shell !!!"
fi
echo "*******************build application end*******************"
